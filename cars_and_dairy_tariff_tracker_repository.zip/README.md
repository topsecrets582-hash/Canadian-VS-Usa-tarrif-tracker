# US & Canada Tariff Impact Tracker 🚗 🥛

An open-source, "zero-install" Python desktop GUI application that scrapes live official trade schedules (USITC, CBSA) and categorizes cross-border tariff duties for the **Automotive** (HS Chapter 87) and **Dairy** (HS Chapter 04) sectors.

![Python](https://img.shields.io/badge/Python-3.8%2B-blue.svg)
![License](https://img.shields.io/badge/License-MIT-green.svg)
![Platform](https://img.shields.io/badge/Platform-Windows-lightgrey.svg)

---

## Key Features

* 🚀 **Zero Dependencies**: Built strictly using Python standard libraries (`urllib`, `re`, `threading`, `tkinter`). No third-party packages required.
* 🛡️ **Guaranteed Foreground Focus**: Automatically forces the GUI window to pop up in front on launch without getting hidden behind active background applications.
* 🌐 **Live Web Scraping & Keyword Engine**: Scrapes government URLs and categorizes Harmonized System (HS) chapter data in real time.
* 📺 **Line-by-Line Streaming Output**: Animates tariff duty breakdowns and market impact assessments dynamically line-by-line.
* ⚡ **One-Click Diagnostic Launcher**: Includes a robust Windows `.bat` script that unblocks security flags (`Unblock-File`) and provides explicit error handling.

---

## Directory Structure

```text
.
├── CLICK_TO_START.bat   # Automated diagnostic launcher for Windows
├── Start.vbs            # Silent VBScript launcher
├── tariff_app.py        # Core Tkinter application & web scraping engine
├── LICENSE              # MIT License text
├── README.md            # GitHub documentation & project guide
└── .gitignore           # Git ignore rules for Python projects
```

---

## Getting Started

### Prerequisites

* Windows 10 or 11
* Python 3.8 or higher installed and added to system `PATH`

### Option 1: One-Click Execution (Windows)

1. Download or clone this repository.
2. Double-click `CLICK_TO_START.bat`.
3. The launcher will automatically unblock local execution policies and open the application.

### Option 2: Direct Terminal Execution

```bash
python tariff_app.py
```

---

## License

This project is open source and available under the [MIT License](LICENSE).
