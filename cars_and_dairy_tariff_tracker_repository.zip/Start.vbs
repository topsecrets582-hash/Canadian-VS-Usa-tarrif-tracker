Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "cmd /c CLICK_TO_START.bat", 0, False
