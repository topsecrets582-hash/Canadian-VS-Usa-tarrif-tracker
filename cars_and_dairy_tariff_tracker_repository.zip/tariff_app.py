"""
US & Canada Cross-Border Tariff Impact Tracker & Scraper
=========================================================
An open-source desktop GUI application built in Python for analyzing 
cross-border tariff duties between the United States and Canada, 
focusing on the Automotive and Dairy sectors under USMCA/CUSMA trade framework.

License: MIT License
"""

import sys
import time
import threading
import urllib.request
import re
import tkinter as tk
from tkinter import ttk, messagebox


class TariffCalculator:
    """Core logic engine for web scraping, sector detection, and tariff duty analysis."""

    DATA = {
        "car": {
            "title": "🚗 AUTOMOTIVE SECTOR (CARS & VEHICLES)",
            "us_hs": "8703 (Passenger Cars) / 8704 (Trucks & Commercial)",
            "us_base": "2.5% MFN Base Duty Rate (Passenger Cars)",
            "us_surtax": "25% Section 232 / Up to 100% Surtax on foreign EVs",
            "us_impact": "Substantial cost markup on non-USMCA foreign vehicles.",
            "ca_hs": "8703 (Passenger Cars) / 8704 (Trucks & Commercial)",
            "ca_base": "6.1% MFN Base Duty Rate",
            "ca_surtax": "100% Surtax on select non-CUSMA foreign electric vehicles",
            "ca_impact": "Shields domestic assembly plants; increases import costs on foreign EVs."
        },
        "dairy": {
            "title": "🥛 DAIRY SECTOR (CHEESE, MILK, WHEY)",
            "us_hs": "0401 - 0406 (Milk, Cream, Cheese, Whey, Butter)",
            "us_base": "10.0% Average In-Quota Tariff-Rate Quota (TRQ)",
            "us_surtax": "Up to 50% Tariff on Canadian whey and specialty cheese",
            "us_impact": "Severe export restrictions on Canadian specialty dairy products.",
            "ca_hs": "0401 - 0406 (Milk, Cream, Cheese, Whey, Butter)",
            "ca_base": "Supply Management TRQ (241% - 298% Over-Quota Duty)",
            "ca_surtax": "25% - 50% Retaliatory Surtax on U.S. cheese & whey",
            "ca_impact": "Limits cross-border market access; protects domestic supply management."
        }
    }

    @classmethod
    def analyze_url(cls, raw_input: str) -> tuple[str, str]:
        """Scrapes web page HTML content and classifies sector based on HS Chapters and keywords."""
        text = raw_input.lower()
        title = "Direct Keyword Query"

        if raw_input.startswith("http://") or raw_input.startswith("https://"):
            try:
                req = urllib.request.Request(
                    raw_input, 
                    headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
                )
                with urllib.request.urlopen(req, timeout=4) as resp:
                    html = resp.read().decode('utf-8', errors='ignore').lower()
                    title_match = re.search(r'<title>(.*?)</title>', html, re.IGNORECASE)
                    if title_match:
                        title = title_match.group(1).strip()[:60]
                    text += " " + html
            except Exception:
                title = "Parsed URL Query (Offline / Direct Endpoint)"

        dairy_keywords = [
            "dairy", "milk", "cheese", "butter", "whey", "yogurt", "cream",
            "ch04", "/ch04", "chapter 04", "0401", "0402", "0406"
        ]
        
        if any(w in text for w in dairy_keywords):
            return "dairy", title
        return "car", title


class TariffApp(tk.Tk):
    """Main Desktop GUI Application using native Tkinter styling."""

    def __init__(self):
        super().__init__()

        self.title("US & Canada Tariff Impact Tracker")
        self.geometry("880x660")
        self.configure(bg="#1e1e2e")

        # Foreground window pop-up focus
        self.deiconify()
        self.lift()
        self.attributes('-topmost', True)
        self.after(200, lambda: self.attributes('-topmost', False))
        self.focus_force()

        # Modern Dark Theme Styles
        self.style = ttk.Style()
        self.style.theme_use("clam")
        self.style.configure("TFrame", background="#1e1e2e")
        self.style.configure("Header.TLabel", font=("Segoe UI", 16, "bold"), foreground="#89b4fa", background="#1e1e2e")
        self.style.configure("SubHeader.TLabel", font=("Segoe UI", 10), foreground="#a6adc8", background="#1e1e2e")
        self.style.configure("blue.Horizontal.TProgressbar", troughcolor="#313244", background="#89b4fa", thickness=10)

        # Header Section
        header = ttk.Frame(self)
        header.pack(fill="x", padx=20, pady=(15, 5))

        ttk.Label(header, text="🚗 🥛 US & Canada Tariff Impact Tracker", style="Header.TLabel").pack(anchor="w")
        ttk.Label(header, text="Select a sector preset or paste a link/keyword to evaluate cross-border duties.", style="SubHeader.TLabel").pack(anchor="w", pady=(2, 0))

        # Controls & Input Bar
        controls = ttk.Frame(self)
        controls.pack(fill="x", padx=20, pady=10)

        btn_car = tk.Button(
            controls, text="🚗 Cars & Vehicles", font=("Segoe UI", 10, "bold"),
            bg="#313244", fg="#89b4fa", activebackground="#45475a", relief="flat", padx=12, pady=6,
            command=lambda: self.load_sector("car")
        )
        btn_car.pack(side="left", padx=(0, 8))

        btn_dairy = tk.Button(
            controls, text="🥛 Dairy Products", font=("Segoe UI", 10, "bold"),
            bg="#313244", fg="#a6e3a1", activebackground="#45475a", relief="flat", padx=12, pady=6,
            command=lambda: self.load_sector("dairy")
        )
        btn_dairy.pack(side="left", padx=(0, 15))

        self.url_entry = tk.Entry(
            controls, font=("Segoe UI", 10), bg="#313244", fg="#cdd6f4",
            insertbackground="#cdd6f4", relief="flat", bd=6
        )
        self.url_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))

        self.btn_analyze = tk.Button(
            controls, text="Analyze Link", font=("Segoe UI", 10, "bold"),
            bg="#89b4fa", fg="#11111b", activebackground="#b4befe", relief="flat", padx=12, pady=6,
            command=self.start_analysis
        )
        self.btn_analyze.pack(side="left")

        # Progress Bar Frame
        p_frame = ttk.Frame(self)
        p_frame.pack(fill="x", padx=20, pady=(2, 5))

        self.progress = ttk.Progressbar(p_frame, orient="horizontal", mode="determinate", style="blue.Horizontal.TProgressbar")
        self.progress.pack(fill="x")

        # Status Label
        self.status_var = tk.StringVar(value="Ready. Select Cars or Dairy above, or paste a link.")
        tk.Label(self, textvariable=self.status_var, font=("Segoe UI", 9, "italic"), bg="#1e1e2e", fg="#a6adc8").pack(anchor="w", padx=20, pady=2)

        # Output Cards (Side-by-Side)
        cards = ttk.Frame(self)
        cards.pack(fill="both", expand=True, padx=20, pady=10)

        # US Output Box
        us_group = tk.LabelFrame(cards, text=" 🇺🇸 US Duty & Tariff Impact ", font=("Segoe UI", 11, "bold"), bg="#181825", fg="#89b4fa", bd=1, relief="solid")
        us_group.pack(side="left", fill="both", expand=True, padx=(0, 8))

        self.us_text = tk.Text(us_group, font=("Consolas", 10), bg="#181825", fg="#cdd6f4", relief="flat", wrap="word", bd=10)
        self.us_text.pack(fill="both", expand=True)

        # Canada Output Box
        ca_group = tk.LabelFrame(cards, text=" 🇨🇦 Canada Duty & Tariff Impact ", font=("Segoe UI", 11, "bold"), bg="#181825", fg="#a6e3a1", bd=1, relief="solid")
        ca_group.pack(side="right", fill="both", expand=True, padx=(8, 0))

        self.ca_text = tk.Text(ca_group, font=("Consolas", 10), bg="#181825", fg="#cdd6f4", relief="flat", wrap="word", bd=10)
        self.ca_text.pack(fill="both", expand=True)

        # Pre-load Cars sector on start
        self.load_sector("car")

    def load_sector(self, key):
        d = TariffCalculator.DATA[key]
        self.status_var.set(f"Loaded sector: {d['title']}")

        self.us_text.delete("1.0", tk.END)
        self.ca_text.delete("1.0", tk.END)

        us_str = f"SECTOR: {d['title']}\nHTS CODE: {d['us_hs']}\n\nBase Duty Rate:\n{d['us_base']}\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nSpecial Surtax Rules:\n{d['us_surtax']}\n\nMarket Impact:\n{d['us_impact']}"
        ca_str = f"SECTOR: {d['title']}\nTARIFF CODE: {d['ca_hs']}\n\nBase Duty Rate:\n{d['ca_base']}\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nSpecial Surtax Rules:\n{d['ca_surtax']}\n\nMarket Impact:\n{d['ca_impact']}"

        self.us_text.insert("1.0", us_str)
        self.ca_text.insert("1.0", ca_str)

    def start_analysis(self):
        raw = self.url_entry.get().strip()
        if not raw:
            self.status_var.set("⚠️ Please enter a link or keyword first.")
            return

        self.btn_analyze.config(state="disabled")
        self.progress["value"] = 0
        self.status_var.set("⏳ Scraping web link & fetching HTS schedule parameters...")

        self.us_text.delete("1.0", tk.END)
        self.ca_text.delete("1.0", tk.END)

        threading.Thread(target=self._run_analysis, args=(raw,), daemon=True).start()

    def _run_analysis(self, raw):
        for i in range(1, 50):
            time.sleep(0.01)
            self.progress["value"] = i
            self.update_idletasks()

        key, title = TariffCalculator.analyze_url(raw)
        d = TariffCalculator.DATA[key]

        for i in range(50, 101):
            time.sleep(0.01)
            self.progress["value"] = i
            self.update_idletasks()

        us_lines = [
            f"SOURCE PAGE: {title}",
            f"SECTOR: {d['title']}",
            f"HTS CODE: {d['us_hs']}",
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
            f"Base Duty Rate: {d['us_base']}",
            f"Special Surtax: {d['us_surtax']}",
            "",
            "ECONOMIC & MARKET IMPACT:",
            f"{d['us_impact']}"
        ]

        ca_lines = [
            f"SOURCE PAGE: {title}",
            f"SECTOR: {d['title']}",
            f"TARIFF CODE: {d['ca_hs']}",
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
            f"Base Duty Rate: {d['ca_base']}",
            f"Special Surtax: {d['ca_surtax']}",
            "",
            "ECONOMIC & MARKET IMPACT:",
            f"{d['ca_impact']}"
        ]

        max_len = max(len(us_lines), len(ca_lines))
        for idx in range(max_len):
            time.sleep(0.1)
            if idx < len(us_lines):
                self.us_text.insert(tk.END, us_lines[idx] + "\n")
                self.us_text.see(tk.END)
            if idx < len(ca_lines):
                self.ca_text.insert(tk.END, ca_lines[idx] + "\n")
                self.ca_text.see(tk.END)
            self.update_idletasks()

        self.btn_analyze.config(state="normal")
        self.status_var.set("✓ Analysis complete! Tariff rates updated below.")


if __name__ == "__main__":
    app = TariffApp()
    app.mainloop()
