@echo off
title US & Canada Tariff Tracker Diagnostic Launcher
cls
echo ========================================================
echo        US & Canada Tariff Tracker Launcher
echo ========================================================
echo.

echo [1/3] Unblocking Windows security restrictions...
powershell -Command "Get-ChildItem -Recurse | Unblock-File" >nul 2>&1

echo [2/3] Checking Python setup...
where python >nul 2>&1
if %errorlevel% equ 0 (
    echo [3/3] Running tariff_app.py...
    python tariff_app.py
    if %errorlevel% neq 0 pause
    exit /b
)

where py >nul 2>&1
if %errorlevel% equ 0 (
    echo [3/3] Running tariff_app.py via 'py'...
    py tariff_app.py
    if %errorlevel% neq 0 pause
    exit /b
)

echo.
echo ========================================================
echo ERROR: Python is NOT detected on this system!
echo ========================================================
echo Please install Python from https://www.python.org/
echo Check the box "Add Python.exe to PATH" during setup.
echo ========================================================
echo.
pause
